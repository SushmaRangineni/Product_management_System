package com.tcs.prodMngmtStm.service.serviceImpl;

import com.tcs.prodMngmtStm.entity.Product;
import com.tcs.prodMngmtStm.exception.ProductNotFoundException;
import com.tcs.prodMngmtStm.model.ProductDto;
import com.tcs.prodMngmtStm.repository.ProdMngmtRepo;
import com.tcs.prodMngmtStm.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProdMngmtRepo prodRepo;

    @Override
    public List<ProductDto> getProductDtls(){
        return prodRepo.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ProductDto createProduct(ProductDto prdDto) {

        Product prd = new Product();
      //  prd.setPId(prdDto.getPId());
        prd.setPName(prdDto.getPName());
        prd.setPrice(prdDto.getPrice());
        prd.setReview(prdDto.getReview());

        Product savedPrd = prodRepo.save(prd);
        return convertToDTO(savedPrd);
    }



    @Override
    public ProductDto getProductById(Long id) {

        Product prd =   prodRepo.findById(id).orElseThrow(()
                -> new ProductNotFoundException("Product not found with id: " + id));

        return convertToDTO(prd);
    }

    @Override
    public ProductDto updatePrdById(Long id, ProductDto prdDto) {
        Product pd = prodRepo.findById(id).orElseThrow(()
                -> new ProductNotFoundException("Product not found with id: " + id));

        pd.setPName(prdDto.getPName());
        pd.setPrice(prdDto.getPrice());
        pd.setReview(prdDto.getReview());
        Product pdSave =  prodRepo.save(pd);

        return convertToDTO(pdSave);
    }

    @Override
    public void deleteProdById(Long id) {

        if (!prodRepo.existsById(id)) {
            throw new ProductNotFoundException("Product not found with id: " + id);
        }
        //Product pd = getProductById(id);
        prodRepo.deleteById(id);
    }

    private ProductDto convertToDTO(Product prd) {
        ProductDto dto = new ProductDto();
        dto.setPId(prd.getPId());
        dto.setPName(prd.getPName());
        dto.setPrice(prd.getPrice());
        dto.setReview(prd.getReview());
        return dto;
    }
}
