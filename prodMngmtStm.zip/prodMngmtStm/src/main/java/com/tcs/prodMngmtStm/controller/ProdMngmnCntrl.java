package com.tcs.prodMngmtStm.controller;

import com.tcs.prodMngmtStm.model.ProductDto;
import com.tcs.prodMngmtStm.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/prod")
public class ProdMngmnCntrl {

    @Autowired
    private ProductService prodSrvs;

    @GetMapping("/get")
    public List<ProductDto> getProductDtls(){
       return prodSrvs.getProductDtls();
    }

    @PostMapping("/save")
    public ProductDto createProduct(@Valid @RequestBody ProductDto prd){
       return  prodSrvs.createProduct(prd);
    }

    @GetMapping("/{id}")
    public ProductDto getProductById(@PathVariable Long id) {
        return prodSrvs.getProductById(id);
    }

    @PutMapping("/update/{id}")
    public ProductDto updatePrdById(@PathVariable Long id, @Valid @RequestBody ProductDto productDto) {
        return prodSrvs.updatePrdById(id, productDto);
    }

    @DeleteMapping("/{id}")
    public void deleteProdById(@PathVariable Long id) {
        prodSrvs.deleteProdById(id);
    }
}
