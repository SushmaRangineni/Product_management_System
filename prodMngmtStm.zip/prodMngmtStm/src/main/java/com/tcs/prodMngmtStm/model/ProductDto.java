package com.tcs.prodMngmtStm.model;


import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;


//@AllArgsConstructor
//@NoArgsConstructor
@Setter
@Getter
@Data
public class ProductDto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pId;

    @NotBlank(message = "Product name is required")
    @Size(min = 2, max = 50, message = "Product name must be between 2 and 50 characters")
    private String pName;

    @Min(value = 0, message = "Price must be 1 ore more rupees")
    private Double price;

    @Size(max = 100, message = "Review must not exceed 100 characters")
    private String review;

    public ProductDto() {
    }

    public ProductDto(Long pId, String pName, Double price, String review) {
        this.pId = pId;
        this.pName = pName;
        this.price = price;
        this.review = review;
    }
}
