package com.tcs.prodMngmtStm.service;

import com.tcs.prodMngmtStm.model.ProductDto;
import org.springframework.stereotype.Service;

import java.util.List;

//@Service
public interface ProductService {
    List<ProductDto> getProductDtls();

    ProductDto createProduct(ProductDto prd);

    ProductDto getProductById(Long id);

    ProductDto updatePrdById(Long id, ProductDto productDto);

    void deleteProdById(Long id);
}
