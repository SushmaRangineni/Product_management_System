package com.tcs.prodMngmtStm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdMngmtStmApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdMngmtStmApplication.class, args);
	}

}
