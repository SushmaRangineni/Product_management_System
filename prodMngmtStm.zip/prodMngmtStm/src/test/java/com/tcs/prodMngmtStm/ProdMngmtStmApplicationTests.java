package com.tcs.prodMngmtStm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdMngmtStmApplicationTests {

	@Test
	void contextLoads() {
	}

}
